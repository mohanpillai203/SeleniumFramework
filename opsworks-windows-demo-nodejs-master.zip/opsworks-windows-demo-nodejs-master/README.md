# AWS OpsWorks Node.JS Demo App

A sample Node.JS application running on AWS OpsWorks for Chef 12.2 Windows and Chef 12 Linux.

See also <https://aws.amazon.com/opsworks/>
